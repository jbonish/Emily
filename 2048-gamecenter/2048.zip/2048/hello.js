var express = require("express");
var logfmt = require("logfmt");
var mongo = require("mongodb");

var app = express();

var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://mongolab.com:53708/heroku_app24031788';
var db = mongo.Db.connect(mongoUri, function(err, connect){
	db = connect;
});

app.use(logfmt.requestLogger());
app.use(express.json());
app.use(express.urlencoded());


var port = Number(process.env.PORT || 5000);
app.listen(port, function() {
  console.log("Listening on " + port);
});

app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.post('/submit.json', function(req, res){
	var username = req.body.username;
	console.log(username);
	var score =  parseInt(req.body.score);
	var grid = req.body.grid;
	var created_at = new Date();
	if (username != "" && score != "" && grid != "") {
		db.collection('scores', function(err, collection) {
			collection.insert({"username": username, "score": score, "grid": grid, "created_at": created_at},
			function(err, docs){res.send("Data added to database")});
			});
	} else {
		res.send("Missing data");
	}
});

app.get('/scores.json', function(req, res) {
	var username = req.query.username;
	db.collection('scores', function(err, collection)
	{
		var users = collection.find({username:username}).sort({score:-1});
		var scores = users.toArray(function(err, data) {
			res.send(data);
		});
	});
});

app.get('/', function(req, res){

	var scores;
	var format = "<h1> James Bonish 2048</h1><h3>High Scores </h3><ol>";
	db.collection('scores', function(err,collection){
		var allscores = collection.find({}).sort({score: -1});
		scores = allscores.toArray(function(err,results){
			results.forEach(function(score){
				format += ('<li>'+'Username: '+score.username+', Score: '+score.score+', Time Stamp: '+score.created_at+'</li>');
			});	
			format += '</ol>';	
			res.send(format);	
		});
	});
});